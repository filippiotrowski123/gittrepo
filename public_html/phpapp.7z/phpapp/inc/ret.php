$ret
foreach ($ret as $k => $t)
Array (
	[0] => Array (
				[id] => 1 [0] => 1
				[plik] => witam [1] => witam
				[tytul] => Witamy [2] => Witamy
				[pozycja] => 1 [3] => 1
			)
			$t['tytul']
	[1] => Array ( [id] => 2 [0] => 2 [plik] => formularz [1] => formularz [tytul] => Formularz [2] => Formularz [pozycja] => 2 [3] => 2 )
	[2] => Array ( [id] => 3 [0] => 3 [plik] => klasa [1] => klasa [tytul] => Klasa [2] => Klasa [pozycja] => 3 [3] => 3 )
)