#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  petla.py

def main(args):
    for i in range(10):
        print(i)
        print("Hello")
    
    return 0

if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))
