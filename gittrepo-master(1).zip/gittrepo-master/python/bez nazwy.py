#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  bez nazwy.py


def main(args):
    a=0
    a=1
    print(a)
        
    return 0

if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))
