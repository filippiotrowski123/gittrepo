#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  bmi.py – body mass index
#  bmi = masa / (wzrost^2)
# BMI < 18,5 – niedowaga
# BMI 18,5-24,9 – norma
# BMI >= 25 – nadwaga
# BMI >= 30 – otyłość

def main(args):
    masa = pass
    wzrost = pass
    
    return 0

if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))
