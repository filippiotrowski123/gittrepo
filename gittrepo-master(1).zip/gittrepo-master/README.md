# gittrepo
Repozytorium dla klasy 1A 2018
